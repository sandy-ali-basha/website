import * as React from "react";
import { Unstable_NumberInput as BaseNumberInput } from "@mui/base/Unstable_NumberInput";
import { styled } from "@mui/system";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";
import { _cart } from "api/cart/_cart";
import { useQueryClient } from "react-query";
import { _currencies } from "api/country/country";
const NumberInput = React.forwardRef(function CustomNumberInput(props, ref) {
  return (
    <BaseNumberInput
      slots={{
        root: StyledInputRoot,
        input: StyledInput,
        incrementButton: StyledButton,
        decrementButton: StyledButton,
      }}
      slotProps={{
        incrementButton: {
          children: <AddIcon fontSize="small" />,
          className: "increment",
        },
        decrementButton: {
          children: <RemoveIcon fontSize="small" />,
        },
      }}
      {...props}
      ref={ref}
    />
  );
});

export default function QuantityInput({ max, quantity, product, cartID }) {
  console.log("QuantityInput product:", product);
  const [currencies, setCurrencies] = React.useState([]);

  // fetch currencies once
  const fetchCurrencies = React.useCallback(async () => {
    try {
      const res = await _currencies.getAll();
      if (res?.data) setCurrencies(res.data);
      return res?.data || [];
    } catch (err) {
      console.error("Failed to fetch currencies", err);
      return [];
    }
  }, []);

  // Ensure currencies are loaded
  let currencyList = currencies;

  const queryClient = useQueryClient();
  const handleQuantityChange = async (event, value) => {
    if (!currencyList.length) {
      currencyList = await fetchCurrencies(); // wait until currencies are fetched
    }
    // const currencyName = selectedVariant?.currency?.name;
    // const currency_id = currencyObj?.id || 1; // fallback

    // const currencyObj = currencyList.find(
    //   (c) => c.name.toLowerCase() === currencyName?.toLowerCase()
    // );
    const updatedQuantity = value;
    const data = {
      products: {
        [product.id]: {
          qty: updatedQuantity,
        },
      },
    };
    // const data = {
    //   currency_id,
    //   user_id: user_data ? user_data?.id : null,
    //   products: [
    //     {
    //       variant_id: selectedVariant?.id,
    //       id: productId,
    //       qty: 1,
    //     },
    //   ],
    // };

    await _cart.UpdateCart({ data, cart_id: cartID }).then(() => {
      queryClient.invalidateQueries("cart");
    });
  };

  return (
    <NumberInput
      aria-label="Quantity Input"
      min={1}
      max={max}
      defaultValue={quantity}
      onChange={handleQuantityChange} // Add onChange handler
    />
  );
}
const blue = {
  100: "#daecff",
  200: "#b6daff",
  300: "#66b2ff",
  400: "#3399ff",
  500: "#007fff",
  600: "#0072e5",
  700: "#0059B2",
  800: "#004c99",
};

const grey = {
  50: "#F3F6F9",
  100: "#E5EAF2",
  200: "#DAE2ED",
  300: "#C7D0DD",
  400: "#B0B8C4",
  500: "#9DA8B7",
  600: "#6B7A90",
  700: "#434D5B",
  800: "#303740",
  900: "#1C2025",
};

const StyledInputRoot = styled("div")(
  ({ theme }) => `
  font-family: 'IBM Plex Sans', sans-serif;
  font-weight: 400;
  color: ${theme.palette.mode === "dark" ? grey[300] : grey[500]};
  display: flex;
  flex-flow: row nowrap;
  justify-content: center;
  align-items: center;
`
);

const StyledInput = styled("input")(
  ({ theme }) => `
  font-size: 0.875rem;
  font-family: inherit;
  font-weight: 400;
  line-height: 1.375;
  color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};
  background: ${theme.palette.mode === "dark" ? grey[900] : "#fff"};
  border: 1px solid ${theme.palette.mode === "dark" ? grey[700] : grey[200]};
  box-shadow: 0px 2px 4px ${
    theme.palette.mode === "dark" ? "rgba(0,0,0, 0.5)" : "rgba(0,0,0, 0.05)"
  };
  border-radius: 8px;
  margin: 0 8px;
  padding: 10px 12px;
  outline: 0;
  min-width: 0;
  width: 4rem;
  text-align: center;

  &:hover {
    border-color: ${blue[400]};
  }

  &:focus {
    border-color: ${blue[400]};
    box-shadow: 0 0 0 3px ${
      theme.palette.mode === "dark" ? blue[700] : blue[200]
    };
  }

  &:focus-visible {
    outline: 0;
  }
`
);

const StyledButton = styled("button")(
  ({ theme }) => `
  font-family: 'IBM Plex Sans', sans-serif;
  font-size: 0.875rem;
  box-sizing: border-box;
  line-height: 1.5;
  border: 1px solid;
  border-radius: 999px;
  border-color: ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
  background: ${theme.palette.mode === "dark" ? grey[900] : grey[50]};
  color: ${theme.palette.mode === "dark" ? grey[200] : grey[900]};
  width: 32px;
  height: 32px;
  display: flex;
  flex-flow: row nowrap;
  justify-content: center;
  align-items: center;
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 120ms;

  &:hover {
    cursor: pointer;
    background: ${theme.palette.mode === "dark" ? blue[700] : blue[500]};
    border-color: ${theme.palette.mode === "dark" ? blue[500] : blue[400]};
    color: ${grey[50]};
  }

  &:focus-visible {
    outline: 0;
  }

  &.increment {
    order: 1;
  }
`
);
